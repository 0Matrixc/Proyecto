/*⚠ PROHIBIDO EDITAR ⚠

El codigo de este archivo esta totalmente hecho por:
- Aiden_NotLogic >> https://github.com/ferhacks

El codigo de este archivo fue parchado por:
- ReyEndymion >> https://github.com/ReyEndymion
- BrunoSobrino >> https://github.com/BrunoSobrino

Contenido adaptado por:
- GataNina-Li >> https://github.com/GataNina-Li
- elrebelde21 >> https://github.com/elrebelde21
*/

const _0x201225=_0x223b;(function(_0x3f1692,_0x2fcd8b){const _0x528380=_0x223b,_0x324d02=_0x3f1692();while(!![]){try{const _0x558873=-parseInt(_0x528380(0x15d))/0x1*(parseInt(_0x528380(0x186))/0x2)+-parseInt(_0x528380(0x169))/0x3*(parseInt(_0x528380(0x16c))/0x4)+parseInt(_0x528380(0x130))/0x5+parseInt(_0x528380(0x171))/0x6+-parseInt(_0x528380(0x12a))/0x7*(parseInt(_0x528380(0x157))/0x8)+-parseInt(_0x528380(0x133))/0x9+parseInt(_0x528380(0x13c))/0xa*(parseInt(_0x528380(0x142))/0xb);if(_0x558873===_0x2fcd8b)break;else _0x324d02['push'](_0x324d02['shift']());}catch(_0x475eee){_0x324d02['push'](_0x324d02['shift']());}}}(_0x1809,0x31ea3));function _0x223b(_0x12542c,_0xd0916e){const _0x180916=_0x1809();return _0x223b=function(_0x223ba9,_0x50eafa){_0x223ba9=_0x223ba9-0x10d;let _0x566dbd=_0x180916[_0x223ba9];return _0x566dbd;},_0x223b(_0x12542c,_0xd0916e);}const {DisconnectReason,useMultiFileAuthState,MessageRetryMap,fetchLatestBaileysVersion,makeCacheableSignalKeyStore,jidNormalizedUser}=await import('@whiskeysockets/baileys');import _0x41f8d1 from'moment-timezone';import _0x174e29 from'awesome-phonenumber';import _0x536ff9 from'readline';import{fileURLToPath}from'url';import _0x153b76 from'crypto';import{readFileSync}from'fs';import{join,dirname}from'path';import*as _0x15b82d from'ws';const {CONNECTING}=_0x15b82d;import{Boom}from'@hapi/boom';import _0x506af4 from'qrcode';import _0x4914d8 from'fs';import _0x210e5b from'pino';import'ws';const {child,spawn,exec}=await import(_0x201225(0x177));import{makeWASocket}from'../lib/simple.js';import _0x4de4c2 from'../lib/store.js';import _0x13df2e from'node-cache';let check1=_0x201225(0x135),check2='ZThkMmNkOGVlMDFmZD',check3=_0x201225(0x17c),check4=_0x201225(0x14d),check5=_0x201225(0x17e),check6='DcgIF9hdXRvcmVzcG9uZGVyLmpzCjU5Yzc0ZjFjNmEz',check8=_0x201225(0x12f),crm1=_0x201225(0x195),crm2='A7IG1kNXN1b',crm3=_0x201225(0x17a),crm4='IF9hdXRvcmVzcG9uZGVyLmpzIGluZm8tYm90Lmpz',drm1=_0x201225(0x188),drm2=_0x201225(0x14c);if(!(global[_0x201225(0x168)]instanceof Array))global['conns']=[];if(!(global[_0x201225(0x16a)]instanceof Array))global[_0x201225(0x16a)]=[];function _0x1809(){const _0x2ff21d=['onCall','*⚠️\x20La\x20conexión\x20se\x20cerró,\x20se\x20intentara\x20reconectar\x20automáticamente...*\x0a','split','connectionLost','sender','rmdirSync','--code','data','smsJBInfo1','trim','*『\x20SER\x20BOT\x20CON\x20CÓDIGO\x20QR\x20』*\x0a✦\x20*Versión\x20de\x20','unlinkSync','_\x0a*No\x20sólo\x20el\x20diseño\x20del\x20mensaje\x20se\x20ha\x20renovado.\x20✨\x20¡Disfruta\x20de\x20','\x20🐈*\x0a\x0a*1️⃣\x20Diríjase\x20a\x20los\x20tres\x20puntos\x20en\x20la\x20esquina\x20superior\x20derecha*\x0a*2️⃣\x20Ir\x20a\x20la\x20opción\x20\x22Dispositivos\x20vinculados\x22\x20y\x20use\x20el\x20botón\x20\x22Vincular\x20un\x20dispositivo\x22*\x0a*3️⃣\x20Escanee\x20este\x20codigo\x20QR\x20para\x20iniciar\x20sesión*\x0a\x0a>\x20📢\x20*¡Este\x20código\x20QR\x20expira\x20en\x2050\x20segundos!*\x0a⚠️\x20_*Como\x20medida\x20de\x20seguridad\x20y\x20para\x20no\x20generar\x20spam,\x20este\x20mensaje\x20será\x20eliminado\x20en\x2050\x20segundos*_\x0a','error','reply','jadibot','chat','utf-8','from','tags','indexOf','silent','*\x0a⚠️\x20_*Como\x20medida\x20de\x20seguridad\x20y\x20para\x20no\x20generar\x20spam,\x20este\x20mensaje\x20y\x20el\x20código\x20será\x20eliminado\x20en\x201\x20minuto*_\x0a','registered','close','40852iizfFN','badSession','parse','settings','remoteJid','NjNmYmJjYzA1YmFiY2MzZGU4MGRlICBpbmZvLWJvdC5qcwo','1143115wKreSS','group-participants.update','smsJBInfo2','304497cAamJt','subreloadHandler','NjBhZGVmZWI4N2M2','mentionedJid','writeFileSync','fstop','base64','Safari','message.delete','30qtBrER','removeAllListeners','now','_\x0a\x0a*No\x20sólo\x20el\x20diseño\x20del\x20mensaje\x20se\x20ha\x20renovado.\x20✨\x20¡Disfruta\x20de\x20','*⚠️\x20Se\x20ha\x20alcanzado\x20el\x20limite\x20de\x20reconexiones,\x20por\x20favor\x20intente\x20mas\x20tarde.*','\x20Por\x20favor\x20reporte\x20al\x20desarollador.','742379ZHMEmj','statusCode','stringify','./GataJadiBot/','connectionReplaced','splice','connection.update','creds.update','*⚠️\x20La\x20conexión\x20se\x20agotó,\x20se\x20intentara\x20reconectar\x20automáticamente...*\x0a','CkphZGlib3QsIEhlY2hvIHBvciBAQWlkZW5fTm90TG9naWM','IHBvciBAQWlkZW5fTm90TG9naWM','m8tZG9uYXIuanMK','/creds.json','smsAvisoIIG','push','creds','log','command','participantsUpdate','jid','output','392pcWyfk','../package.json','mkdirSync','bind','groups.update','restartRequired','36qsTvnA','*✅\x20*¡Conectado\x20con\x20exito!*','existsSync','\x20»*\x20*`','rentbot','help','call','off','sendMessage','onDelete','isInit','conns','90GmoKRl','dataconst','*⚠️\x20El\x20bot\x20se\x20ha\x20apagado\x20correctamente!!*','17156wboIao','deleteUpdate','startsWith','user','*『\x20SER\x20BOT\x20CON\x20CÓDIGO\x20DE\x208\x20DÍGITOS\x20』*\x0a✦\x20*Versión\x20de\x20','1728624hRsgUg','keys','handler','\x0a\x0a💝\x20*Puede\x20hacer\x20una\x20Donación\x20voluntaria\x20por\x20PayPal:*\x0a','utf8','\x0a\x0a🤩\x20*Descubre\x20más\x20formas\x20de\x20seguir\x20pendiente\x20de\x20este\x20proyecto:*\x0a','child_process','GataBot-MD\x20(Sub-Bot)','`*\x0a✦\x20*Descripción\x20»*\x20_','SBpbmZvLWRvbmFyLmpz','connectionClosed','UzYTI1MTQgIGluZ','loadMessage','NzZjM2ZmMzU2MTEyMzM3OTczOWU5ZmFmMDZjYzUzO','vsJB','toString','smsSoloOwnerJB','open','credsUpdate','payload','Ubuntu','3682zpRBHj','readFileSync','CkphZGlib3QsIEhlY2hv','2.0.0','`*\x0a✦\x20*Versión\x20de\x20JadiBot\x20»*\x20*`','messages.upsert','conn','&text=','*La\x20conexión\x20se\x20cerró*,\x20Tendrá\x20que\x20conectarse\x20manualmente\x20usando\x20el\x20comando\x20#serbot*','catch','*⚠️\x20La\x20conexión\x20se\x20perdió,\x20se\x20intentara\x20reconectar\x20automáticamente...*\x0a','20.0.04','loggedOut','521','jadibotmd','Y2QgcGx1Z2lucy','connectionUpdate','timedOut','includes','replace','groupsUpdate'];_0x1809=function(){return _0x2ff21d;};return _0x1809();}const __dirname=dirname(fileURLToPath(import.meta['url'])),packageJsonPath=join(__dirname,_0x201225(0x158)),{name,author,version:versionSB,description}=JSON[_0x201225(0x12c)](readFileSync(packageJsonPath,_0x201225(0x175)));let handler=async(_0x7880ea,{conn:_0x3740e2,args:_0x482a9d,usedPrefix:_0x3b835b,command:_0x37fa95,isOwner:_0x5ca988,text:_0x21b4d5})=>{const _0x2697ff=_0x201225;if(!global['db'][_0x2697ff(0x117)][_0x2697ff(0x12d)][_0x3740e2[_0x2697ff(0x16f)][_0x2697ff(0x155)]][_0x2697ff(0x194)])return _0x3740e2[_0x2697ff(0x165)](_0x7880ea[_0x2697ff(0x121)],{'text':''+lenguajeGB[_0x2697ff(0x181)]()},{'quoted':_0x7880ea});if(_0x3740e2['user']['jid']!==global['conn']['user']['jid'])return _0x3740e2[_0x2697ff(0x11f)](_0x7880ea[_0x2697ff(0x121)],lenguajeGB['smsJBPrincipal']()+'\x20wa.me/'+global[_0x2697ff(0x18c)]['user'][_0x2697ff(0x155)]['split']`@`[0x0]+_0x2697ff(0x18d)+(_0x3b835b+_0x37fa95),_0x7880ea);const _0x16317d=Buffer[_0x2697ff(0x123)](_0x2697ff(0x14b),'base64');async function _0x400c70(){const _0x1ae63a=_0x2697ff;let _0x4547ac=_0x7880ea[_0x1ae63a(0x136)]&&_0x7880ea[_0x1ae63a(0x136)][0x0]?_0x7880ea[_0x1ae63a(0x136)][0x0]:_0x7880ea['fromMe']?_0x3740e2[_0x1ae63a(0x16f)][_0x1ae63a(0x155)]:_0x7880ea['sender'],_0x9488cf=''+_0x4547ac[_0x1ae63a(0x112)]`@`[0x0],_0x4bf714=_0x482a9d[0x0]&&_0x482a9d[0x0][_0x1ae63a(0x10d)](_0x1ae63a(0x116))?!![]:!!(_0x482a9d[0x1]&&_0x482a9d[0x1][_0x1ae63a(0x10d)]('--code'));if(_0x4bf714){_0x482a9d[0x0]=_0x482a9d[0x0][_0x1ae63a(0x10e)](_0x1ae63a(0x116),'')[_0x1ae63a(0x119)]();if(_0x482a9d[0x1])_0x482a9d[0x1]=_0x482a9d[0x1]['replace']('--code','')[_0x1ae63a(0x119)]();if(_0x482a9d[0x0]=='')_0x482a9d[0x0]=undefined;}!_0x4914d8[_0x1ae63a(0x15f)](_0x1ae63a(0x145)+_0x9488cf)&&_0x4914d8[_0x1ae63a(0x159)]('./GataJadiBot/'+_0x9488cf,{'recursive':!![]});_0x482a9d[0x0]&&_0x4914d8[_0x1ae63a(0x137)](_0x1ae63a(0x145)+_0x9488cf+_0x1ae63a(0x14e),JSON[_0x1ae63a(0x144)](JSON[_0x1ae63a(0x12c)](Buffer['from'](_0x482a9d[0x0],_0x1ae63a(0x139))[_0x1ae63a(0x180)](_0x1ae63a(0x122))),null,'\x09'));if(_0x4914d8[_0x1ae63a(0x15f)](_0x1ae63a(0x145)+_0x9488cf+_0x1ae63a(0x14e))){let _0x13bbfc=JSON[_0x1ae63a(0x12c)](_0x4914d8['readFileSync'](_0x1ae63a(0x145)+_0x9488cf+_0x1ae63a(0x14e)));_0x13bbfc&&((_0x13bbfc[_0x1ae63a(0x128)]=![])&&_0x4914d8[_0x1ae63a(0x11b)](_0x1ae63a(0x145)+_0x9488cf+'/creds.json'));}const {state:_0x761f83,saveState:_0x3e9b9f,saveCreds:_0x35e0cd}=await useMultiFileAuthState(_0x1ae63a(0x145)+_0x9488cf),_0xf11b6f=new _0x13df2e(),{version:_0x24196c}=await fetchLatestBaileysVersion(),_0xbe00d5={'printQRInTerminal':![],'auth':{'creds':_0x761f83[_0x1ae63a(0x151)],'keys':makeCacheableSignalKeyStore(_0x761f83[_0x1ae63a(0x172)],_0x210e5b({'level':'silent'}))},'logger':_0x210e5b({'level':_0x1ae63a(0x126)}),'browser':_0x4bf714?[_0x1ae63a(0x185),'Chrome',_0x1ae63a(0x191)]:[_0x1ae63a(0x178),_0x1ae63a(0x13a),_0x1ae63a(0x189)],'markOnlineOnConnect':!![],'generateHighQualityLinkPreview':!![],'getMessage':async _0x30b015=>{const _0x638e60=_0x1ae63a;let _0x4d7675=jidNormalizedUser(_0x30b015[_0x638e60(0x12e)]),_0x39c0d9=await _0x4de4c2[_0x638e60(0x17d)](_0x4d7675,_0x30b015['id']);return _0x39c0d9?.['message']||'';},'msgRetryCounterCache':_0xf11b6f,'version':_0x24196c};let _0x4aeb83=makeWASocket(_0xbe00d5);_0x4aeb83[_0x1ae63a(0x167)]=![],_0x4aeb83['uptime']=Date[_0x1ae63a(0x13e)]();let _0x3d5916=!![];async function _0x3c8cc7(_0x3457a1){const _0x1ce782=_0x1ae63a,{connection:_0x3489ac,lastDisconnect:_0x39cf06,isNewLogin:_0x441091,qr:_0x62fe70}=_0x3457a1;if(_0x441091)_0x4aeb83[_0x1ce782(0x167)]=![];_0x62fe70&&!_0x4bf714&&_0x3740e2['sendMessage'](_0x7880ea[_0x1ce782(0x121)],{'image':await _0x506af4['toBuffer'](_0x62fe70,{'scale':0x8}),'caption':_0x1ce782(0x11a)+name+_0x1ce782(0x160)+versionSB+_0x1ce782(0x18a)+global[_0x1ce782(0x17f)]+_0x1ce782(0x179)+description+_0x1ce782(0x11c)+name+'!*\x0a>\x20➡️\x20*Usando\x20otro\x20celular\x20o\x20en\x20la\x20PC\x20escanea\x20este\x20código\x20QR\x20para\x20convertirte\x20en\x20Sub\x20Bot\x20de\x20'+name+_0x1ce782(0x11d)+_0x16317d[_0x1ce782(0x180)](_0x1ce782(0x122))},{'quoted':_0x7880ea});if(_0x62fe70&&_0x4bf714){let _0x995bc7=_0x7880ea[_0x1ce782(0x114)]['split']`@`[0x0];if(_0x995bc7[_0x1ce782(0x16e)]('52'))_0x995bc7=_0x1ce782(0x193)+_0x995bc7['slice'](0x2);let _0x5e5fc5=await _0x4aeb83['requestPairingCode'](_0x995bc7);_0x3740e2[_0x1ce782(0x165)](_0x7880ea[_0x1ce782(0x121)],{'text':_0x1ce782(0x170)+name+_0x1ce782(0x160)+versionSB+_0x1ce782(0x18a)+global[_0x1ce782(0x17f)]+_0x1ce782(0x179)+description+_0x1ce782(0x13f)+name+'!*\x0a>\x20*Se\x20enviará\x20un\x20código\x20para\x20ser\x20Sub\x20Bot*\x0a\x0a1️⃣\x20*Diríjase\x20a\x20los\x20tres\x20puntos\x20en\x20la\x20esquina\x20superior\x20derecha*\x0a\x0a2️⃣\x20*Selecciona\x20\x22Dispositivos\x20vinculados\x22\x20y\x20use\x20el\x20botón\x20\x22Vincular\x20un\x20dispositivo\x22*\x0a\x0a3️⃣\x20*Selecciona\x20en\x20la\x20parte\x20inferior\x20\x22Vincular\x20con\x20el\x20número\x20de\x20teléfono\x22*\x0a\x0a4️⃣\x20*Introduzca\x20el\x20código\x20de\x208\x20dígitos*\x0a\x0a*El\x20código\x20solo\x20será\x20válido\x20para\x20@'+phoneNumber+_0x1ce782(0x127)+_0x16317d[_0x1ce782(0x180)](_0x1ce782(0x122))},{'quoted':_0x7880ea}),await delay(0x1388),_0x3740e2[_0x1ce782(0x165)](_0x7880ea[_0x1ce782(0x121)],{'text':_0x5e5fc5},{'quoted':_0x7880ea});}const _0x598aa9=_0x39cf06?.[_0x1ce782(0x11e)]?.[_0x1ce782(0x156)]?.[_0x1ce782(0x143)]||_0x39cf06?.['error']?.[_0x1ce782(0x156)]?.[_0x1ce782(0x184)]?.['statusCode'];if(_0x3489ac===_0x1ce782(0x129)){if(_0x4aeb83[_0x1ce782(0x16f)]&&dataconst[_0x4aeb83[_0x1ce782(0x16f)]['id']['split']('@')]==0x3)return _0x3740e2['sendMessage'](_0x7880ea[_0x1ce782(0x121)],{'text':_0x1ce782(0x140)},{'quoted':_0x7880ea});if(_0x598aa9==0x195||_0x598aa9==0x194)return _0x4914d8[_0x1ce782(0x11b)](_0x1ce782(0x145)+_0x9488cf+_0x1ce782(0x14e)),_0x400c70();if(_0x598aa9===DisconnectReason[_0x1ce782(0x12b)])_0x3740e2[_0x1ce782(0x165)](_0x7880ea[_0x1ce782(0x121)],{'text':'*⚠️\x20La\x20sesión\x20actual\x20es\x20inválida,\x20Tendras\x20que\x20iniciar\x20sesion\x20de\x20nuevo.'},{'quoted':_0x7880ea}),_0x4914d8[_0x1ce782(0x115)](_0x1ce782(0x145)+_0x9488cf,{'recursive':!![]});else{if(_0x598aa9===DisconnectReason[_0x1ce782(0x17b)]){if(_0x4aeb83['fstop'])return _0x3740e2['sendMessage'](_0x7880ea[_0x1ce782(0x121)],{'text':_0x1ce782(0x16b)},{'quoted':_0x7880ea});!_0x4aeb83[_0x1ce782(0x138)]&&_0x3740e2[_0x1ce782(0x165)](_0x7880ea[_0x1ce782(0x121)],{'text':_0x1ce782(0x111)+dataconst[_0x4aeb83[_0x1ce782(0x16f)]['id']['split']('@')]+'/3'},{'quoted':_0x7880ea}),!_0x4aeb83['fstop']&&await _0x1e3080(!![])[_0x1ce782(0x18f)](console[_0x1ce782(0x11e)]);}else{if(_0x598aa9===DisconnectReason[_0x1ce782(0x113)])_0x3740e2[_0x1ce782(0x165)](_0x7880ea['chat'],{'text':_0x1ce782(0x190)+dataconst[_0x4aeb83['user']['id']['split']('@')]+'/3'},{'quoted':_0x7880ea}),await _0x1e3080(!![])[_0x1ce782(0x18f)](console[_0x1ce782(0x11e)]);else{if(_0x598aa9===DisconnectReason[_0x1ce782(0x146)])_0x3740e2[_0x1ce782(0x165)](_0x7880ea[_0x1ce782(0x121)],{'text':'*⚠️\x20La\x20conexión\x20se\x20reemplazó,\x20Su\x20conexion\x20se\x20cerro*\x0a\x0a*Para\x20volver\x20a\x20conectarte\x20usa:*\x0a'+_0x3b835b+_0x37fa95},{'quoted':_0x7880ea});else{if(_0x598aa9===DisconnectReason[_0x1ce782(0x192)])return _0x3740e2[_0x1ce782(0x165)](_0x7880ea[_0x1ce782(0x121)],{'text':_0x1ce782(0x18e)},{'quoted':_0x7880ea}),_0x4914d8['rmdirSync'](_0x1ce782(0x145)+_0x9488cf,{'recursive':!![]});else{if(_0x598aa9===DisconnectReason[_0x1ce782(0x15c)])await _0x1e3080(!![])['catch'](console[_0x1ce782(0x11e)]);else _0x598aa9===DisconnectReason[_0x1ce782(0x197)]?(_0x3740e2[_0x1ce782(0x165)](_0x7880ea[_0x1ce782(0x121)],{'text':_0x1ce782(0x14a)+dataconst[_0x4aeb83[_0x1ce782(0x16f)]['id'][_0x1ce782(0x112)]('@')]+'/3'},{'quoted':_0x7880ea}),await _0x1e3080(!![])[_0x1ce782(0x18f)](console[_0x1ce782(0x11e)])):_0x3740e2[_0x1ce782(0x165)](_0x7880ea['chat'],{'text':'⚠️\x20Razón\x20de\x20desconexión\x20desconocida.\x20'+(_0x598aa9||'')+':\x20'+(_0x3489ac||'')+_0x1ce782(0x141)},{'quoted':_0x7880ea});}}}}}let _0x533c5b=global[_0x1ce782(0x168)][_0x1ce782(0x125)](_0x4aeb83);if(_0x533c5b<0x0)return console['log']('no\x20se\x20encontro');delete global[_0x1ce782(0x168)][_0x533c5b],global[_0x1ce782(0x168)][_0x1ce782(0x147)](_0x533c5b,0x1);}if(global['db'][_0x1ce782(0x117)]==null)loadDatabase();if(_0x3489ac=='open'){_0x4aeb83['isInit']=!![],global[_0x1ce782(0x168)][_0x1ce782(0x150)](_0x4aeb83),await _0x3740e2[_0x1ce782(0x165)](_0x7880ea[_0x1ce782(0x121)],{'text':_0x482a9d[0x0]?_0x1ce782(0x15e):'✅\x20*Conectado\x20con\x20WhatsApp*\x0a\x0a♻️\x20*Comandos\x20relacionados\x20con\x20Sub\x20Bot:*\x0a»\x20*#stop*\x20_(Pausar\x20ser\x20bot)_\x0a»\x20*#eliminarsesion*\x20_(Dejar\x20de\x20ser\x20bot\x20y\x20eliminar\x20datos)_\x0a»\x20*#serbot\x20[texto\x20largo]*\x20_(Reanudar\x20ser\x20Bot\x20en\x20caso\x20que\x20este\x20pausado\x20o\x20deje\x20de\x20funcionar)_\x0a\x0a*Gracias\x20por\x20usar\x20❤️'+name+'\x20🐈*\x0a\x0a📢\x20*Informate\x20de\x20las\x20novedades\x20en\x20nuestro\x20canal\x20oficial:*\x0a'+canal2+_0x1ce782(0x176)+cuentas+_0x1ce782(0x174)+paypal},{'quoted':_0x7880ea});if(_0x3489ac===_0x1ce782(0x182))return dataconst[_0x4aeb83[_0x1ce782(0x16f)]['id']['split']('@')]=0x1,_0x3740e2[_0x1ce782(0x165)](_0x7880ea[_0x1ce782(0x121)],{'text':lenguajeGB[_0x1ce782(0x14f)]()+'⚪\x20*ESTÁ\x20CONECTADO(A)!!\x20POR\x20FAVOR\x20ESPERE\x20SE\x20ESTÁ\x20CARGANDO\x20LOS\x20MENSAJES...*\x0a\x0a♻️\x20*OPCIONES\x20DISPONIBLES:*\x0a*»\x20#stop\x20_(Detener\x20la\x20función\x20Sub\x20Bot)_*\x0a*»\x20#eliminarsesion\x20_(Borrar\x20todo\x20rastro\x20de\x20Sub\x20Bot)_*\x0a*»\x20#serbot\x20_(Obtener\x20nuevo\x20código\x20QR\x20para\x20ser\x20Sub\x20Bot)_*'},{'quoted':_0x7880ea}),console[_0x1ce782(0x152)](await _0x1e3080(![])[_0x1ce782(0x18f)](console[_0x1ce782(0x11e)]));await sleep(0x1388),!_0x482a9d[0x0]&&(await parent['sendMessage'](_0x3740e2[_0x1ce782(0x16f)]['jid'],{'text':lenguajeGB[_0x1ce782(0x118)]()+'\x20'+lenguajeGB[_0x1ce782(0x132)]()},{'quoted':_0x7880ea}),_0x3740e2['sendMessage'](_0x3740e2[_0x1ce782(0x16f)][_0x1ce782(0x155)],{'text':_0x3b835b+_0x37fa95+'\x20'+Buffer[_0x1ce782(0x123)](_0x4914d8[_0x1ce782(0x187)]('./GataJadiBot/'+_0x9488cf+_0x1ce782(0x14e)),'utf-8')[_0x1ce782(0x180)](_0x1ce782(0x139))},{'quoted':_0x7880ea}));}}setInterval(async()=>{const _0x3ccd48=_0x1ae63a;if(!_0x4aeb83[_0x3ccd48(0x16f)]){try{_0x4aeb83['ws'][_0x3ccd48(0x129)]();}catch{}_0x4aeb83['ev'][_0x3ccd48(0x13d)]();let _0x393ef2=global[_0x3ccd48(0x168)]['indexOf'](_0x4aeb83);if(_0x393ef2<0x0)return;delete global[_0x3ccd48(0x168)][_0x393ef2],global[_0x3ccd48(0x168)][_0x3ccd48(0x147)](_0x393ef2,0x1);}},0xea60);let _0x133659=global['handler'],_0x1e3080=async function(_0x4b048b){const _0x1f8503=_0x1ae63a;try{const _0x34d8b8=await import('../handler.js?update='+Date[_0x1f8503(0x13e)]())[_0x1f8503(0x18f)](console[_0x1f8503(0x11e)]);if(Object[_0x1f8503(0x172)](_0x34d8b8||{})['length'])_0x133659=_0x34d8b8;}catch(_0x4e4a48){console[_0x1f8503(0x11e)](_0x4e4a48);}if(_0x4b048b){try{_0x4aeb83['ws'][_0x1f8503(0x129)]();}catch{}_0x4aeb83['ev'][_0x1f8503(0x13d)](),_0x4aeb83=makeWASocket(_0xbe00d5),_0x3d5916=!![];}return _0x4aeb83[_0x1f8503(0x16f)]&&_0x4aeb83[_0x1f8503(0x16f)]['id']&&!dataconst[_0x4aeb83[_0x1f8503(0x16f)]['id'][_0x1f8503(0x112)]('@')]&&(dataconst[_0x4aeb83[_0x1f8503(0x16f)]['id'][_0x1f8503(0x112)]('@')]=0x0),_0x4aeb83['user']&&_0x4aeb83['user']['id']&&dataconst[_0x4aeb83[_0x1f8503(0x16f)]['id'][_0x1f8503(0x112)]('@')]&&_0x4b048b&&dataconst[_0x4aeb83[_0x1f8503(0x16f)]['id'][_0x1f8503(0x112)]('@')]++,!_0x3d5916&&(_0x4aeb83['ev'][_0x1f8503(0x164)](_0x1f8503(0x18b),_0x4aeb83[_0x1f8503(0x173)]),_0x4aeb83['ev']['off'](_0x1f8503(0x131),_0x4aeb83[_0x1f8503(0x154)]),_0x4aeb83['ev'][_0x1f8503(0x164)](_0x1f8503(0x15b),_0x4aeb83[_0x1f8503(0x10f)]),_0x4aeb83['ev']['off'](_0x1f8503(0x13b),_0x4aeb83[_0x1f8503(0x166)]),_0x4aeb83['ev'][_0x1f8503(0x164)](_0x1f8503(0x163),_0x4aeb83[_0x1f8503(0x110)]),_0x4aeb83['ev']['off']('connection.update',_0x4aeb83[_0x1f8503(0x196)]),_0x4aeb83['ev'][_0x1f8503(0x164)](_0x1f8503(0x149),_0x4aeb83[_0x1f8503(0x183)])),_0x4aeb83[_0x1f8503(0x173)]=_0x133659[_0x1f8503(0x173)][_0x1f8503(0x15a)](_0x4aeb83),_0x4aeb83[_0x1f8503(0x154)]=_0x133659['participantsUpdate'][_0x1f8503(0x15a)](_0x4aeb83),_0x4aeb83[_0x1f8503(0x10f)]=_0x133659[_0x1f8503(0x10f)]['bind'](_0x4aeb83),_0x4aeb83[_0x1f8503(0x166)]=_0x133659[_0x1f8503(0x16d)][_0x1f8503(0x15a)](_0x4aeb83),_0x4aeb83[_0x1f8503(0x110)]=_0x133659['callUpdate']['bind'](_0x4aeb83),_0x4aeb83['connectionUpdate']=_0x3c8cc7[_0x1f8503(0x15a)](_0x4aeb83),_0x4aeb83[_0x1f8503(0x183)]=_0x35e0cd['bind'](_0x4aeb83,!![]),_0x4aeb83['ev']['on'](_0x1f8503(0x18b),_0x4aeb83[_0x1f8503(0x173)]),_0x4aeb83['ev']['on'](_0x1f8503(0x131),_0x4aeb83[_0x1f8503(0x154)]),_0x4aeb83['ev']['on'](_0x1f8503(0x15b),_0x4aeb83[_0x1f8503(0x10f)]),_0x4aeb83['ev']['on'](_0x1f8503(0x13b),_0x4aeb83[_0x1f8503(0x166)]),_0x4aeb83['ev']['on']('call',_0x4aeb83[_0x1f8503(0x110)]),_0x4aeb83['ev']['on'](_0x1f8503(0x148),_0x4aeb83[_0x1f8503(0x196)]),_0x4aeb83['ev']['on'](_0x1f8503(0x149),_0x4aeb83[_0x1f8503(0x183)]),_0x4aeb83[_0x1f8503(0x134)]=_0x1e3080,_0x3d5916=![],!![];};_0x1e3080(![]);}_0x400c70();};handler[_0x201225(0x162)]=[_0x201225(0x120),'serbot','getcode',_0x201225(0x161)],handler[_0x201225(0x124)]=[_0x201225(0x120)],handler[_0x201225(0x153)]=/^(jadibot|serbot|getcode|rentbot|code)$/i;export default handler;const delay=_0x2c320e=>new Promise(_0x1f76b1=>setTimeout(_0x1f76b1,_0x2c320e));function sleep(_0x557480){return new Promise(_0x136d51=>setTimeout(_0x136d51,_0x557480));}

/*// Créditos: https://github.com/FG98F
// Código adaptado por GataNina-Li

const { useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion, MessageRetryMap, makeCacheableSignalKeyStore, jidNormalizedUser, PHONENUMBER_MCC } = await import('@whiskeysockets/baileys')
import moment from 'moment-timezone'
import PhoneNumber from 'awesome-phonenumber'
import NodeCache from 'node-cache'
import readline from 'readline'
import qrcode from "qrcode"
import { fileURLToPath } from 'url'
import crypto from 'crypto'
import fs from "fs"
import { readFileSync } from 'fs'
import { join, dirname } from 'path'
import pino from 'pino'
import * as ws from 'ws'
const { CONNECTING } = ws
import { Boom } from '@hapi/boom'
import { makeWASocket } from '../lib/simple.js'

if (global.conns instanceof Array) console.log()
else global.conns = []

const __dirname = dirname(fileURLToPath(import.meta.url))
const packageJsonPath = join(__dirname, '../package.json')
const { name, author, version: versionSB, description } = JSON.parse(readFileSync(packageJsonPath, 'utf8'))

let folderBot = 'GataBotSession', nameBotMD = 'GataBot-MD', opcion = ''
let handler = async (m, { conn: _conn, args, usedPrefix, command, isOwner, text }) => {
if (!global.db.data.settings[conn.user.jid].jadibotmd) return _conn.sendMessage(m.chat, { text: `${lenguajeGB['smsSoloOwnerJB']()}` }, { quoted: m })
  
let parent = args[0] && args[0] == 'plz' ? _conn : await global.conn
text = (text ? text : (args[0] ? args[0] : '')).toLowerCase()

let message1 = `*Si desea convertirse en bot, diríjase al número principal*\n\nwa.me/${global.conn.user.jid.split('@')[0]}?text=${usedPrefix}serbot`
if (!((args[0] && args[0] == 'plz') || (await global.conn).user.jid == _conn.user.jid)) {
if (text.includes('qr')) {
return parent.sendMessage(m.chat, { text: message1 + '%20qr' }, { quoted: m })
} else if (text.includes('code')) {
return parent.sendMessage(m.chat, { text: message1 + '%20code' }, { quoted: m })
} else {
return parent.sendMessage(m.chat, { text: message1 + '%20code' }, { quoted: m })
}}
  
let authFolderB = crypto.randomBytes(10).toString('hex').slice(0, 8)
async function serbot() {
if (!fs.existsSync(`./${folderBot}/` + authFolderB)){
fs.mkdirSync(`./${folderBot}/` + authFolderB, { recursive: true })
}
args[0] ? fs.writeFileSync(`./${folderBot}/` + authFolderB + "/creds.json", JSON.stringify(JSON.parse(Buffer.from(args[0], "base64").toString("utf-8")), null, '\t')) : ""
  
const { state, saveState, saveCreds } = await useMultiFileAuthState(`./${folderBot}/${authFolderB}`)
const msgRetryCounterMap = (MessageRetryMap) => { }
const msgRetryCounterCache = new NodeCache()
const {version} = await fetchLatestBaileysVersion()
let phoneNumber = m.sender.split('@')[0]

const methodCodeQR = text.includes('qr') || false
const methodCode = text.includes('code') || true
const MethodMobile = process.argv.includes("mobile")

if (text.includes('qr')) {
opcion = '1'
} else if (text.includes('code')) {
opcion = '2'
} else {
opcion = '2'
}

const connectionOptions = {
logger: pino({ level: 'silent' }),
printQRInTerminal: opcion == '1' ? true : methodCodeQR ? true : false,
mobile: MethodMobile, 
browser: opcion == '1' ? [`${nameBotMD} (sub bot)`, 'Edge', '2.0.0'] : ['Ubuntu', 'Edge', '110.0.1587.56'], 
auth: { creds: state.creds, keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "fatal" }).child({ level: "fatal" })), },
markOnlineOnConnect: true, 
generateHighQualityLinkPreview: true, 
getMessage: async (clave) => {
let jid = jidNormalizedUser(clave.remoteJid)
let msg = await store.loadMessage(jid, clave.id)
return msg?.message || ""
},
msgRetryCounterCache,
msgRetryCounterMap,
defaultQueryTimeoutMs: undefined,   
version
}

let conn = makeWASocket(connectionOptions)
conn.isInit = false
let isInit = true

let cleanedNumber = phoneNumber.replace(/[^0-9]/g, '')
  
let txt = ''
if (!fs.existsSync(`./${folderBot}/` + authFolderB + "/creds.json")){
if (opcion == '1') {
txt = `*『 SER BOT CON CÓDIGO QR 』*\n
✦ *Versión de ${name} »* *\`${versionSB}\`*
✦ *Versión de JadiBot »* *\`${global.vsJB}\`*
✦ *Descripción »* _${description}_\n
*No sólo el diseño del mensaje se ha renovado. ✨ ¡Disfruta de ${name}!*\n
> ➡️ *Usando otro celular o en la PC escanea este código QR para convertirte en Sub Bot de ${name} 🐈*\n\n*1️⃣ Diríjase a los tres puntos en la esquina superior derecha*\n*2️⃣ Ir a la opción "Dispositivos vinculados" y use el botón "Vincular un dispositivo"*\n*3️⃣ Escanee este codigo QR para iniciar sesión*\n\n> 📢 *¡Este código QR expira en 50 segundos!*\n
⚠️ _*Como medida de seguridad y para no generar spam, este mensaje será eliminado en 50 segundos*_`
} else {  
txt = `*『 SER BOT CON CÓDIGO DE 8 DÍGITOS 』*\n
✦ *Versión de ${name} »* *\`${versionSB}\`*
✦ *Versión de JadiBot »* *\`${global.vsJB}\`*
✦ *Descripción »* _${description}_\n
*No sólo el diseño del mensaje se ha renovado. ✨ ¡Disfruta de ${name}!*\n
> *Se enviará un código para ser Sub Bot*\n\n1️⃣ *Diríjase a los tres puntos en la esquina superior derecha*\n\n2️⃣ *Selecciona "Dispositivos vinculados" y use el botón "Vincular un dispositivo"*\n\n3️⃣ *Selecciona en la parte inferior "Vincular con el número de teléfono"*\n\n4️⃣ *Introduzca el código de 8 dígitos*\n

*El código solo será válido para @${phoneNumber}*\n
⚠️ _*Como medida de seguridad y para no generar spam, este mensaje y el código será eliminado en 1 minuto*_`

let codeA, codeB 
setTimeout(async () => {
let codeBot = await conn.requestPairingCode(cleanedNumber)
codeBot = codeBot?.match(/.{1,4}/g)?.join("-") || codeBot
codeA = await parent.sendMessage(m.chat, { text: txt.trim(), mentions: [m.sender] }, { quoted: m })  
codeB = await parent.sendMessage(m.chat, { text: codeBot }, { quoted: m })
}, 2000)

setTimeout(() => {
parent.sendMessage(m.chat, { delete: codeA.key })
parent.sendMessage(m.chat, { delete: codeB.key })
}, 60000) // 1 min
}
}
async function connectionUpdate(update) {
const { connection, lastDisconnect, isNewLogin, qr } = update
if (isNewLogin) conn.isInit = true
if (opcion == '1') {
let scan = await parent.sendFile(m.chat, await qrcode.toDataURL(qr, { scale: 8 }), 'qrcode.png', txt.trim(), m)
setTimeout(() => {
parent.sendMessage(m.chat, { delete: scan.key })
}, 50000) //50 segundos
}
const code = lastDisconnect?.error?.output?.statusCode || lastDisconnect?.error?.output?.payload?.statusCode
if (code && code !== DisconnectReason.loggedOut && conn?.ws.socket == null) {
let i = global.conns.indexOf(conn)
if (i < 0) { 
console.log(await creloadHandler(true).catch(console.error))
}
delete global.conns[i]
global.conns.splice(i, 1)
if (code !== DisconnectReason.connectionClosed) {
parent.sendMessage(m.chat, { text: "*Conexión perdida...* vuelva a intentarlo" }, { quoted: m })
} else {
parent.sendMessage(m.chat, { text: "*La conexión se cerró*, Tendrá que conectarse manualmente usando el comando #serbot" }, { quoted: m })
}}
    
if (global.db.data == null) loadDatabase()
if (connection == 'open') {
conn.isInit = true
global.conns.push(conn)
await parent.sendMessage(m.chat, {text : args[0] ? '✅ *¡Conectado con exito!*' : `✅ *Conectado con WhatsApp*\n\n♻️ *Comandos relacionados con Sub Bot:*\n» *#stop* _(Pausar ser bot)_\n» *#eliminarsesion* _(Dejar de ser bot y eliminar datos)_\n» *#serbot [texto largo]* _(Reanudar ser Bot en caso que este pausado o deje de funcionar)_\n\n*Gracias por usar ❤️${name} 🐈*\n\n📢 *Informate de las novedades en nuestro canal oficial:*\n${canal2}\n\n🤩 *Descubre más formas de seguir pendiente de este proyecto:*\n${cuentas}\n\n💝 *Puede hacer una Donación voluntaria por PayPal:*\n${paypal}` }, { quoted: m })
await parent.sendMessage(m.chat, { text: `🤭 *¡Sigue de cerca este nuevo proyecto!*\nhttps://whatsapp.com/channel/0029VabS4KD8KMqeVXXmkG1D` }, { quoted: m })  
args[0] ? console.log(`*Usuario Sub Bot reconectandose: ${PhoneNumber('+' + (conn.user?.jid).replace('@s.whatsapp.net', '')).getNumber('international')} (${conn.getName(conn.user.jid)})*`) : console.log(`*Nuevo usuario conectado como Sub Bot: ${PhoneNumber('+' + (conn.user?.jid).replace('@s.whatsapp.net', '')).getNumber('international')} (${conn.getName(conn.user.jid)})*`)
await sleep(5000)
if (args[0]) return
await parent.sendMessage(conn.user.jid, {text : '*Si pausa ser sub bot o deja de funcionar, envíe este mensaje para intentar conectarse nuevamente*'}, { quoted: m })
await parent.sendMessage(conn.user.jid, {text : usedPrefix + command + " " + Buffer.from(fs.readFileSync(`./${folderBot}/` + authFolderB + "/creds.json"), "utf-8").toString("base64")}, { quoted: m })
}}

setInterval(async () => {
if (!conn.user) {
try { conn.ws.close() } catch { }
conn.ev.removeAllListeners()
let i = global.conns.indexOf(conn)
if (i < 0) return
delete global.conns[i]
global.conns.splice(i, 1)
}}, 60000)
    
let handler = await import('../handler.js')
let creloadHandler = async function (restatConn) {
try {
const Handler = await import(`../handler.js?update=${Date.now()}`).catch(console.error)
if (Object.keys(Handler || {}).length) handler = Handler
} catch (e) {
console.error(e)
}
if (restatConn) {
try { conn.ws.close() } catch { }
conn.ev.removeAllListeners()
conn = makeWASocket(connectionOptions)
isInit = true
}

if (!isInit) {
conn.ev.off('messages.upsert', conn.handler)
conn.ev.off('connection.update', conn.connectionUpdate)
conn.ev.off('creds.update', conn.credsUpdate)
}
  
conn.handler = handler.handler.bind(conn)
conn.connectionUpdate = connectionUpdate.bind(conn)
conn.credsUpdate = saveCreds.bind(conn, true)

conn.ev.on('messages.upsert', conn.handler)
conn.ev.on('connection.update', conn.connectionUpdate)
conn.ev.on('creds.update', conn.credsUpdate)
isInit = false
return true
}
creloadHandler(false)
}
serbot()
  
}
handler.command = ['jadibot', 'serbot']
export default handler

function sleep(ms) {
return new Promise(resolve => setTimeout(resolve, ms))
}

function isBase64(text) {
const validChars = /^[A-Za-z0-9+/]*={0,2}$/
if (text.length % 4 === 0 && validChars.test(text)) {
const decoded = Buffer.from(text, 'base64').toString('base64')
return decoded === text
}
return false
}

function fileExists(filePath) {
try {
return fs.statSync(filePath).isFile()
} catch (err) {
return false
}}
*/