# !/bin/bash
yarn install && npm start
